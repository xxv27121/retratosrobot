package PruebaPractica;

import java.util.Scanner;

public class PruebaPractica {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.print("Introduce un valor del 1 al 4 para el pelo: ");
		int pelo = in.nextInt();
		System.out.print("Introduce un valor del 1 al 4 para los ojos: ");
		int ojos = in.nextInt();
		System.out.print("Introduce un valor del 1 al 4 para las orejas/nariz: ");
		int nariz = in.nextInt();
		System.out.print("Introduce un valor del 1 al 4 para la boca: ");
		int boca = in.nextInt();
		System.out.print("Introduce un valor del 1 al 4 para la barbilla: ");
		int barba = in.nextInt();
		System.out.println(pelor);
		System.out.println(ojosr);
		System.out.println(narizr);
		System.out.println(bocar);
		System.out.println(barbar);
	}
	
/*Estoy atascado y no se como invocar un método
 * el próximo saldrá mejor.
 * 
 */
		
		
		public String pelor(int a) {
			String pelo;
			if (a == 1)
					return ("WWWWWWWWW");
			else if (a == 2)
					return ("\\\//////");
			else if (a == 3)
					return ("'|||||||'");
			else if (a == 4)
					return ("|||||||||");
		}
		public String ojosr(int a) {
			String ojos;
			if (a == 1)
					return ("| o   o |");
			if (a == 2)
					return ("|-(· ·)-|");
			if (a == 3)
					return ("|-(o o)-|");
			if (a == 4)
					return ("| \   / |");
		}
		public String narizr(int a) {
			String nariz;
			if (a == 1)
					return ("@   J   @");
			if (a == 2)
					return ("(   "   )"); 
			if (a == 3)
					return ("[   j   ]");
			if (a == 4)
					return ("<   -   >");
		}
		public String bocar(int a) {
			String boca;
			if (a == 1)
					return ("|  ===  |");
			if (a == 2)
					return ("|   -   |");
			if (a == 3)
					return ("|  ___  |");
			if (a == 4)
					return ("|  ---  |");
		}
			public String barbar(int a) {
				String barba;
				if (a == 1)
						return ("\_______/");
				if (a == 2)
						return ("\,,,,,,,/");
				if (a == 3)
						return ("\......./");
				if (a == 4)
						return ("\mmmmmmm/");
		
}
}
